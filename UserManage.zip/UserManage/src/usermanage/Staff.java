package usermanage;
public class Staff extends User {
    private String name;
    private int division; // 1 marketing, 2 HRD, 3 sales

    public Staff(String username, String password, String noTelp, String name, int division) {
        super(username, password, noTelp);
        
        this.name = name;
        this.division = division;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getDivision() {
        return division;
    }

    public void setDivision(int division) {
        this.division = division;
    }
    
}
