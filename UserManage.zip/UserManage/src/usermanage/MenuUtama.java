package usermanage;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class MenuUtama extends javax.swing.JFrame {

    final String MYSQL_URL = "jdbc:mysql://localhost:3306/db_usermanage";
    final String MYSQL_DRIVER = "com.mysql.cj.jdbc.Driver";
    final String USERNAME = "root";
    final String PASSWORD = "";

    Statement STATEMENT = null;
    PreparedStatement PREPARED_STMT = null;
    Connection CONN = null;
    ResultSet RS;

    private ArrayList<Customer> listCustomer;
    private ArrayList<Staff> listStaff;
    private ArrayList<Partner> listPartner;

    public MenuUtama() {
        initComponents();

        listCustomer = new ArrayList<>();
        listStaff = new ArrayList<>();
        listPartner = new ArrayList<>();

        init();

    }

    private void getAllListCustomer() {
        try {
            Class.forName(MYSQL_DRIVER);
            CONN = DriverManager.getConnection(MYSQL_URL, USERNAME, PASSWORD);
            STATEMENT = CONN.createStatement();
            RS = STATEMENT.executeQuery("SELECT * FROM customer");

            while (RS.next()) {
                listCustomer.add(new Customer(
                        RS.getString("username"),
                        RS.getString("password"),
                        RS.getString("noTelp"),
                        RS.getString("name")
                ));
            }

            RS.close();
            STATEMENT.close();
            CONN.close();
        } catch (HeadlessException | ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void getAllListStaff() {
        try {
            Class.forName(MYSQL_DRIVER);
            CONN = DriverManager.getConnection(MYSQL_URL, USERNAME, PASSWORD);
            STATEMENT = CONN.createStatement();
            RS = STATEMENT.executeQuery("SELECT * FROM staff");

            while (RS.next()) {
                listStaff.add(new Staff(
                        RS.getString("username"),
                        RS.getString("password"),
                        RS.getString("noTelp"),
                        RS.getString("name"),
                        RS.getInt("division")
                ));
            }

            RS.close();
            STATEMENT.close();
            CONN.close();
        } catch (HeadlessException | ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void getAllListPartner() {
        try {
            Class.forName(MYSQL_DRIVER);
            CONN = DriverManager.getConnection(MYSQL_URL, USERNAME, PASSWORD);
            STATEMENT = CONN.createStatement();
            RS = STATEMENT.executeQuery("SELECT * FROM partner");

            while (RS.next()) {
                listPartner.add(new Partner(
                        RS.getString("username"),
                        RS.getString("password"),
                        RS.getString("noTelp"),
                        RS.getString("name"),
                        RS.getString("companyName"),
                        RS.getString("address")
                ));
            }

            RS.close();
            STATEMENT.close();
            CONN.close();
        } catch (HeadlessException | ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private void setTable() {
        DefaultTableModel tabelModel = new DefaultTableModel();
        // bagian customer
        tabelModel.addColumn("No");
        tabelModel.addColumn("Username");
        tabelModel.addColumn("Password");
        tabelModel.addColumn("No Telepon");
        tabelModel.addColumn("Nama");

        // bagian staff
        tabelModel.addColumn("Divisi");

        // bagian partner
        tabelModel.addColumn("Nama Perusahaan");
        tabelModel.addColumn("Alamat");

        int no = 1;
        int len = listCustomer.size();
        for (int i = 0; i < len; i++) {
            tabelModel.addRow(new Object[]{
                (no + i),
                listCustomer.get(i).getUsername(),
                listCustomer.get(i).getPassword(),
                listCustomer.get(i).getNoTelp(),
                listCustomer.get(i).getName(),
                "-",
                "-",
                "-"
            });

        }

        no += len;
        len = listStaff.size();
        for (int i = 0; i < len; i++) {
            tabelModel.addRow(new Object[]{
                (no + i),
                listStaff.get(i).getUsername(),
                listStaff.get(i).getPassword(),
                listStaff.get(i).getNoTelp(),
                listStaff.get(i).getName(),
                listStaff.get(i).getDivision(),
                "-",
                "-"
            });

        }

        no += len;
        len = listPartner.size();
        for (int i = 0; i < len; i++) {
            tabelModel.addRow(new Object[]{
                (no + i),
                listPartner.get(i).getUsername(),
                listPartner.get(i).getPassword(),
                listPartner.get(i).getNoTelp(),
                listPartner.get(i).getName(),
                "-",
                listPartner.get(i).getCompanyName(),
                listPartner.get(i).getAddress()
            });
        }

        tabelDaftarPengguna.setModel(tabelModel);

    }

    private void setTableAsCustomer() {
        DefaultTableModel tabelModel = new DefaultTableModel();
        // bagian customer
        tabelModel.addColumn("No");
        tabelModel.addColumn("Username");
        tabelModel.addColumn("Password");
        tabelModel.addColumn("No Telepon");
        tabelModel.addColumn("Nama");

        // bagian staff
        tabelModel.addColumn("Divisi");

        // bagian partner
        tabelModel.addColumn("Nama Perusahaan");
        tabelModel.addColumn("Alamat");

        int no = 1;
        int len = listCustomer.size();
        for (int i = 0; i < len; i++) {
            tabelModel.addRow(new Object[]{
                (no + i),
                listCustomer.get(i).getUsername(),
                listCustomer.get(i).getPassword(),
                listCustomer.get(i).getNoTelp(),
                listCustomer.get(i).getName(),
                "-",
                "-",
                "-"
            });
        }
        tabelDaftarPengguna.setModel(tabelModel);
    }

    private void setTableAsStaff() {
        DefaultTableModel tabelModel = new DefaultTableModel();
        // bagian customer
        tabelModel.addColumn("No");
        tabelModel.addColumn("Username");
        tabelModel.addColumn("Password");
        tabelModel.addColumn("No Telepon");
        tabelModel.addColumn("Nama");

        // bagian staff
        tabelModel.addColumn("Divisi");

        // bagian partner
        tabelModel.addColumn("Nama Perusahaan");
        tabelModel.addColumn("Alamat");

        int no = 1;
        int len = listStaff.size();
        for (int i = 0; i < len; i++) {
            tabelModel.addRow(new Object[]{
                (no + i),
                listStaff.get(i).getUsername(),
                listStaff.get(i).getPassword(),
                listStaff.get(i).getNoTelp(),
                listStaff.get(i).getName(),
                listStaff.get(i).getDivision(),
                "-",
                "-"
            });
        }
        tabelDaftarPengguna.setModel(tabelModel);
    }

    private void setTableAsPartner() {
        DefaultTableModel tabelModel = new DefaultTableModel();
        // bagian customer
        tabelModel.addColumn("No");
        tabelModel.addColumn("Username");
        tabelModel.addColumn("Password");
        tabelModel.addColumn("No Telepon");
        tabelModel.addColumn("Nama");

        // bagian staff
        tabelModel.addColumn("Divisi");

        // bagian partner
        tabelModel.addColumn("Nama Perusahaan");
        tabelModel.addColumn("Alamat");

        int no = 1;
        int len = listPartner.size();
        for (int i = 0; i < len; i++) {
            tabelModel.addRow(new Object[]{
                (no + i),
                listPartner.get(i).getUsername(),
                listPartner.get(i).getPassword(),
                listPartner.get(i).getNoTelp(),
                listPartner.get(i).getName(),
                "-",
                listPartner.get(i).getCompanyName(),
                listPartner.get(i).getAddress()
            });
        }
        tabelDaftarPengguna.setModel(tabelModel);
    }

    private boolean isSubStringEquals(String stringLengkap, String subString) {
        boolean hasil = false;

        int panjangStringLengkap = stringLengkap.length();
        int panjangSubString = subString.length();
        
        if(panjangSubString == 0) {
            return true;
        }
        
        for (int i = 0; i < panjangStringLengkap; i++) {
            if (stringLengkap.charAt(i) == subString.charAt(0)) {
                
                if(panjangSubString == 1) {
                    return true;
                }
                
                for (int j = 1; j < panjangSubString; j++) {
                    if ((i + j) >= panjangStringLengkap) {
                        return false;
                    }

                    if (stringLengkap.charAt(i + j) != subString.charAt(j)) {
                        hasil = false;
                        break;
                    } else {
                        hasil = true;
                    }
                }

            }

            if (hasil == true) {
                break;
            }
        }

        return hasil;
    }

    private void setTableCari(String usernameDicari) {
        DefaultTableModel tabelModel = new DefaultTableModel();
        // bagian customer
        tabelModel.addColumn("No");
        tabelModel.addColumn("Username");
        tabelModel.addColumn("Password");
        tabelModel.addColumn("No Telepon");
        tabelModel.addColumn("Nama");

        // bagian staff
        tabelModel.addColumn("Divisi");

        // bagian partner
        tabelModel.addColumn("Nama Perusahaan");
        tabelModel.addColumn("Alamat");

        int no = 1;
        int len = listCustomer.size();
        for (int i = 0; i < len; i++) {
            if (isSubStringEquals(listCustomer.get(i).getUsername(), usernameDicari)) {
                tabelModel.addRow(new Object[]{
                    (no++),
                    listCustomer.get(i).getUsername(),
                    listCustomer.get(i).getPassword(),
                    listCustomer.get(i).getNoTelp(),
                    listCustomer.get(i).getName(),
                    "-",
                    "-",
                    "-"
                });
            }
        }

        len = listStaff.size();
        for (int i = 0; i < len; i++) {
            if (isSubStringEquals(listStaff.get(i).getUsername(), usernameDicari)) {
                tabelModel.addRow(new Object[]{
                    (no++),
                    listStaff.get(i).getUsername(),
                    listStaff.get(i).getPassword(),
                    listStaff.get(i).getNoTelp(),
                    listStaff.get(i).getName(),
                    listStaff.get(i).getDivision(),
                    "-",
                    "-"
                });
            }
        }

        len = listPartner.size();
        for (int i = 0; i < len; i++) {
            if (isSubStringEquals(listPartner.get(i).getUsername(), usernameDicari)) {
                tabelModel.addRow(new Object[]{
                    (no++),
                    listPartner.get(i).getUsername(),
                    listPartner.get(i).getPassword(),
                    listPartner.get(i).getNoTelp(),
                    listPartner.get(i).getName(),
                    "-",
                    listPartner.get(i).getCompanyName(),
                    listPartner.get(i).getAddress()
                });
            }
        }
        tabelDaftarPengguna.setModel(tabelModel);

    }

    private void init() {
        getAllListCustomer();
        getAllListStaff();
        getAllListPartner();

        setTable();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelDaftarPengguna = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtCari = new javax.swing.JTextField();
        btnCari = new javax.swing.JButton();
        rbCustomer = new javax.swing.JRadioButton();
        rbStaff = new javax.swing.JRadioButton();
        rbPartner = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tabelDaftarPengguna.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "No", "Username", "No Telepon", "Name"
            }
        ));
        jScrollPane1.setViewportView(tabelDaftarPengguna);

        jLabel1.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("USER MANAGEMENT APPS");

        btnCari.setText("Cari");
        btnCari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCariActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbCustomer);
        rbCustomer.setText("Customer");
        rbCustomer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbCustomerActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbStaff);
        rbStaff.setText("Staff");
        rbStaff.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbStaffActionPerformed(evt);
            }
        });

        buttonGroup1.add(rbPartner);
        rbPartner.setText("Partner");
        rbPartner.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbPartnerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 789, Short.MAX_VALUE)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(btnCari, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(rbCustomer)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rbStaff)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rbPartner)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbCustomer)
                    .addComponent(rbStaff)
                    .addComponent(rbPartner))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCari, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCari))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 345, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnCariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCariActionPerformed
        String usernameDicari = txtCari.getText();
        setTableCari(usernameDicari);
    }//GEN-LAST:event_btnCariActionPerformed

    private void rbCustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbCustomerActionPerformed
        if(rbCustomer.isSelected()) {
            setTableAsCustomer();
        }
    }//GEN-LAST:event_rbCustomerActionPerformed

    private void rbStaffActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbStaffActionPerformed
        if(rbStaff.isSelected()) {
            setTableAsStaff();
        }
    }//GEN-LAST:event_rbStaffActionPerformed

    private void rbPartnerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbPartnerActionPerformed
        if(rbPartner.isSelected()) {
            setTableAsPartner();
        }
    }//GEN-LAST:event_rbPartnerActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MenuUtama().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCari;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbCustomer;
    private javax.swing.JRadioButton rbPartner;
    private javax.swing.JRadioButton rbStaff;
    private javax.swing.JTable tabelDaftarPengguna;
    private javax.swing.JTextField txtCari;
    // End of variables declaration//GEN-END:variables
}
