package usermanage;

import java.time.ZonedDateTime;

public class Customer extends User {
    private String name;
    private ZonedDateTime lastPurchaseDate;

    public Customer(String username, String password, String noTelp, String name) {
        super(username, password, noTelp);
        
        this.name = name;
        this.lastPurchaseDate = ZonedDateTime.now();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ZonedDateTime getLastPurchaseDate() {
        return lastPurchaseDate;
    }

    public void setLastPurchaseDate(ZonedDateTime lastPurchaseDate) {
        this.lastPurchaseDate = lastPurchaseDate;
    }
    
}
