-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 29, 2021 at 01:05 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_usermanage`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `noTelp` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `lastPurchaseDate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`username`, `password`, `noTelp`, `name`, `lastPurchaseDate`) VALUES
('cust1', 'cust1', '12345', 'Customer 1', '2021-12-29T05:11:22.357+07:00[Asia/Bangkok]'),
('cust2', 'cust2', '23456', 'Customer 2', '2021-12-28T05:11:22.357+07:00[Asia/Bangkok]'),
('cust3', 'cust3', '34567', 'Customer 3', '2021-12-27T05:11:22.357+07:00[Asia/Bangkok]'),
('cust4', 'cust4', '45678', 'Customer 4', '2021-12-26T05:11:22.357+07:00[Asia/Bangkok]'),
('cust5', 'cust5', '56789', 'Customer 5', '2021-12-25T05:11:22.357+07:00[Asia/Bangkok]');

-- --------------------------------------------------------

--
-- Table structure for table `partner`
--

CREATE TABLE `partner` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `noTelp` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `companyName` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `partner`
--

INSERT INTO `partner` (`username`, `password`, `noTelp`, `name`, `companyName`, `address`) VALUES
('part1', 'part1', '09876', 'Partner 1', 'PT. Partner 1', 'Jalan Partner 1'),
('part2', 'part2', '98767', 'Partner 2', 'PT. Partner 2', 'Jalan Partner 2'),
('part3', 'part3', '87678', 'Partner 3', 'PT. Partner 3', 'Jalan Partner 3'),
('part4', 'part4', '76789', 'Partner 4', 'PT. Partner 4', 'Jalan Partner 4'),
('part5', 'part5', '67890', 'Partner 5', 'PT. Partner 5', 'Jalan Partner 5');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `noTelp` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `division` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`username`, `password`, `noTelp`, `name`, `division`) VALUES
('staff1', 'staff1', '1029', 'Staff 1', '1'),
('staff2', 'staff2', '1028', 'Staff 2', '2'),
('staff3', 'staff3', '1027', 'Staff 3', '1'),
('staff4', 'staff4', '1026', 'Staff 4', '3'),
('staff5', 'staff5', '1025', 'Staff 5', '3');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`username`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
